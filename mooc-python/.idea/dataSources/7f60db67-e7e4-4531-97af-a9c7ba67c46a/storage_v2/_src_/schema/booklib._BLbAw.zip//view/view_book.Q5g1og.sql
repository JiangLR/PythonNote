create view view_book as
  select
    `b`.`barcode`       AS `barcode`,
    `b`.`bookname`      AS `bookname`,
    `b`.`pubid`         AS `pubid`,
    `b`.`price`         AS `price`,
    `b`.`state`         AS `state`,
    `p`.`publisherName` AS `publishername`
  from `booklib`.`beanbook` `b`
    join `booklib`.`beanpublisher` `p`
  where (`b`.`pubid` = `p`.`pubid`);

