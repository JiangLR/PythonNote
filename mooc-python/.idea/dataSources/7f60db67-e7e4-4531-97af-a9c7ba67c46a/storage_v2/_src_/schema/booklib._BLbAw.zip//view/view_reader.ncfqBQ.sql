create view view_reader as
  select
    `r`.`readerid`         AS `readerid`,
    `r`.`readerName`       AS `readerName`,
    `r`.`readerTypeId`     AS `readerTypeId`,
    `r`.`lendBookLimitted` AS `lendBookLimitted`,
    `r`.`createDate`       AS `createDate`,
    `r`.`creatorUserId`    AS `creatorUserId`,
    `r`.`stopDate`         AS `stopDate`,
    `r`.`stopUserId`       AS `stopUserId`,
    `rt`.`readerTypeName`  AS `readerTypeName`,
    `r`.`removeDate`       AS `removeDate`
  from `booklib`.`beanreader` `r`
    join `booklib`.`beanreadertype` `rt`
  where (`r`.`readerTypeId` = `rt`.`readerTypeId`);

