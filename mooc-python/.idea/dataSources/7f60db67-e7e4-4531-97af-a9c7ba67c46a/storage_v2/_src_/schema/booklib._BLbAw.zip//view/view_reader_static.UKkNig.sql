create view view_reader_static as
  select
    `r`.`readerid`   AS `readerid`,
    `r`.`readerName` AS `readerName`,
    count(0)         AS `lendcount`
  from `booklib`.`beanreader` `r`
    join `booklib`.`beanbooklendrecord` `rc`
  where (`r`.`readerid` = `rc`.`readerid`)
  group by `r`.`readerid`, `r`.`readerName`;

